var wms_layers = [];


        var lyr_GoogleHybrid_0 = new ol.layer.Tile({
            'title': 'Google Hybrid',
            'type':'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: '&nbsp;&middot; <a href="https://www.google.at/permissions/geoguidelines/attr-guide.html">Map data ©2015 Google</a>',
                url: 'https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}'
            })
        });
var format_Vectorized_1 = new ol.format.GeoJSON();
var features_Vectorized_1 = format_Vectorized_1.readFeatures(json_Vectorized_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Vectorized_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Vectorized_1.addFeatures(features_Vectorized_1);
var lyr_Vectorized_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Vectorized_1, 
                style: style_Vectorized_1,
                popuplayertitle: 'Vectorized',
                interactive: false,
    title: 'Vectorized<br />\
    <img src="styles/legend/Vectorized_1_0.png" /> Water<br />\
    <img src="styles/legend/Vectorized_1_1.png" /> Non Building/Housing<br />\
    <img src="styles/legend/Vectorized_1_2.png" /> Slum<br />\
    <img src="styles/legend/Vectorized_1_3.png" /> Non Slum<br />' });

lyr_GoogleHybrid_0.setVisible(true);lyr_Vectorized_1.setVisible(true);
var layersList = [lyr_GoogleHybrid_0,lyr_Vectorized_1];
lyr_Vectorized_1.set('fieldAliases', {'fid': 'fid', 'DN': 'DN', });
lyr_Vectorized_1.set('fieldImages', {'fid': 'TextEdit', 'DN': 'Range', });
lyr_Vectorized_1.set('fieldLabels', {'fid': 'no label', 'DN': 'no label', });
lyr_Vectorized_1.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});